# Brazilian Data Validation API (RapidAPI Ready)

API para validação de CPF, CNPJ e consulta de CEP brasileiro.
Compatível com RapidAPI.
